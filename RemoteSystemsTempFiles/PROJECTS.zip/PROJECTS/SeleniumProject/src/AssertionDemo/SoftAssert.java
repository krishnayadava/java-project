package AssertionDemo;

import org.testng.annotations.Test;


public class SoftAssert {
	SoftAssert softAssertion= new SoftAssert();
	
	@Test
	public void testsoft(){
		
		System.out.println("open chrome");
		
		
		
		softAssertion.assertAll();
		
		
	}

	
		// TODO Auto-generated method stub
		
	}
	

	

}
